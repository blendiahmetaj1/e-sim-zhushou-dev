// ==UserScript==
// @name         e-sim 自动双击
// @namespace    EsimAWT
// @version      0.2
// @description  模拟人工双击，最安全的e-sim双击插件
// @author       Exsper
// @match        http://*.e-sim.org/*
// @match        https://*.e-sim.org/*
// @grant        none
// ==/UserScript==

//---------------------------------------------设置区---------------------------------------------
var autoWorkEnable = true; //自动工作
var autoTrainEnable = true; //自动训练
var autoFlight = true; //自动工作时：不在国内自动飞行至工厂所在地
var flightTicketQuality = 1; //飞行使用的机票等级，值为1-5
//------------------------------------------------------------------------------------------------

main();

function setValue(item, value) { //储存数据
    localStorage['AWT-' + item] = value;
}

function getValue(item) { //读取数据
    item = 'AWT-' + item;
    return (item in localStorage) ? localStorage[item] : null;
}

function gE(ele, mode, parent) { //获取元素
    if (typeof ele === 'object') {
        return ele;
    } else if (mode === undefined && parent === undefined) {
        return (isNaN(ele * 1)) ? document.querySelector(ele) : document.getElementById(ele);
    } else if (mode === 'all') {
        return (parent === undefined) ? document.querySelectorAll(ele) : parent.querySelectorAll(ele);
    } else if (typeof mode === 'object' && parent === undefined) {
        return mode.querySelector(ele);
    }
}

function cE(name) { //创建元素
    return document.createElement(name);
}

function openUrl(url, newTab) { //跳转网页
    var a = gE('body').appendChild(cE('a'));
    a.href = url;
    a.target = newTab ? '_blank' : '_self';
    a.click();
}

function checkState()
{
    var needWork = false;
    var needTrain = false;

    //确定是否需要双击
    var workButton = $("#taskButtonWork");
    if (workButton.length >0)
    {
        if (autoWorkEnable === true)
        {
            setValue('isWorked', false);
            needWork = true;
        }
        else
        {
            //不要自动工作也视为已工作过
            setValue('isWorked', true);
        }
    }
    else
    {
        setValue('isWorked', true);
    }

    var trainButton = $("#taskButtonTrain");
    if (trainButton.length >0)
    {
        if (autoTrainEnable === true)
        {
            setValue('isTrained', false);
            needTrain = true;
        }
        else
        {
            //不要自动训练也视为已训练过
            setValue('isTrained', true);
        }
    }
    else
    {
        setValue('isTrained', true);
    }

    if (needWork === true || needTrain === true)
    {
        //添加按钮
        var dailyButton = $("#dailyButton");
        var taskButtonAWT = $('<li>', {id:'taskButtonAWT'}).appendTo(dailyButton);
        var startButton = $('<button>', {id:'AWTstart', class:"button foundation-style smallhelp only-icon profileButton", title:"自动双击"}).appendTo(taskButtonAWT);
        var startButtonIcon = $('<i>', {class:"icon-bomb"}).appendTo(startButton);

        startButton.click(function() {
            start();
        });
    }
}

function main() {
    if ( $(".time").length !== 2) {
        console.log("未登录，AWT停止运行");
        return;
    }
    /*
    if ($(".time:first").text().match(/-/g).length != 2) {
        console.log("官方脚本还未执行，AWT等待0.5秒");
        setTimeout(main, 500);
        return;
    }
    */

    if(getValue('started') == "true")
    {
        if (document.URL.search("html") != -1) {
            var url = document.URL.match("\/([a-zA-Z0-9]+)\.html")[1];
            switch (url) {
                case "work":
                    autoWork();
                    break;
                case "train":
                    autoTrain();
                    break;
                case "region":
                    autoFly();
                    break;
                case "travel":
                    flyResult();
                    break;
                default:
                    //进了别的网页，应该是人为操作，停止双击
                    stop();
                    alert("奇怪的错误：非双击网页");
                    break;
            }
        }
    }
    else
    {
        checkState();
    }
}

function start()
{
    setValue('isAutoTrained', false);
    setValue('isAutoWorked', false);
    setValue('started', true);
    toAutoWork();
}

function finish()
{
    stop();
    document.title = "〈双击 已完成〉";
}

function stop()
{
    setValue('isAutoTrained', false);
    setValue('isAutoWorked', false);
    setValue('started', false);
}

function toAutoWork()
{
    //判断是否需要工作
    if ((getValue('isWorked') == "true"))
    {
        //不需要工作
        toAutoTrain();
    }
    else //需要工作
    {
        //这里如果防止过快可以加入等待
        openUrl( location.origin + "/work.html" );
    }
}

function toAutoTrain()
{
    //判断是否需要训练
    if (getValue('isTrained') == "true")
    {
        //不需要训练
        finish();
    }
    else //需要训练
    {
        //这里如果防止过快可以加入等待
        openUrl( location.origin + "/train.html" );
    }
}

//先工作再训练
function autoTrain()
{
    //判断是否需要训练
    if (getValue('isTrained') == "true")
    {
        //不需要训练
        finish();
    }
    else //需要训练
    {
        if (getValue('isAutoTrained') == "true") //已点击过训练按钮
        {
            var tbt = $("#taskButtonTrain");
            if (tbt.length <= 0)
            {
                //顺利完成自动训练
                finish();
            }
            else
            {
                //已经自动训练过却未训练成功
                alert("训练出错，停止双击：" + $(".testDivred :last")[0].childNodes[1].nodeValue);
                stop();
            }
        }
        else //未点击过训练按钮
        {
            var trainForm = $("form#command");
            if (trainForm.length <= 0) //没有按钮
            {
                //未训练却没有训练按钮
                alert("奇怪的错误：未训练却没有训练按钮");
                stop();
            }
            else //有按钮
            {
                var trainButton = trainForm.find("input");
                setValue('isAutoTrained', true);
                trainButton[0].click();
                //页面自动刷新
                //有可能会转至未登录界面，但几率过小，暂不做考虑
            }
        }
    }
}

//先工作再训练
function autoWork()
{
    //判断是否需要工作
    if ((getValue('isWorked') == "true"))
    {
        //不需要工作
        toAutoTrain();
    }
    else //需要工作
    {
        if (getValue('isAutoWorked') == "true") //已点击过工作按钮
        {
            var tbw = $("#taskButtonWork");
            if (tbw.length <= 0)
            {
                //顺利完成自动工作
                toAutoTrain();
            }
            else
            {
                //已经自动工作过却未工作成功
                alert("工作出错，停止双击：" + $(".testDivred :last")[0].childNodes[1].nodeValue);
                stop();
            }
        }
        else //未点击过工作按钮
        {
            var workButton = $(".foundation-style.secondary"); //有按钮时会有2个结果，另一个是聊天框
            if (workButton.length <= 1) //没有按钮
            {
                //未工作却没有工作按钮，可能是还没有职业
                alert("奇怪的错误：未工作却没有工作按钮");
                stop();
            }
            else //有按钮
            {
                if (autoFlight === true) //自动飞行
                {
                    //判断所在地区
                    var regions = $('a[href^="region.html?id="][href!="region.html?id="]');
                    //regions[0] = 人所在地    regions[1] = 工厂所在地
                    //var userLocationId = parseInt(regions.first().attr('href').replace('region.html?id=', ''));
                    //var companyLocationId = parseInt(regions.last().attr('href').replace('region.html?id=', ''));
                    var userLocationCountry = regions.first().parent().next().attr('class');
                    userLocationCountry = userLocationCountry.split(" ").pop();
                    userLocationCountry = userLocationCountry.substring(userLocationCountry.indexOf('-') + 1);
                    var companyLocationCountry = regions.last().parent().find("div").attr('class');
                    companyLocationCountry = companyLocationCountry.split(" ").pop();
                    companyLocationCountry = companyLocationCountry.substring(companyLocationCountry.indexOf('-') + 1);
                    if (userLocationCountry == companyLocationCountry) //在国内
                    {
                        setValue('isAutoWorked', true);
                        workButton[0].click();
                        //页面自动刷新
                        //有可能会转至未登录界面，但几率过小，暂不做考虑
                    }
                    else //不在国内，去工厂所在地区界面
                    {
                        openUrl( location.origin + "/" + regions.last().attr('href') );
                    }
                }
                else
                {
                    setValue('isAutoWorked', true);
                    workButton[0].click();
                    //页面自动刷新
                    //有可能会转至未登录界面，但几率过小，暂不做考虑
                }
            }
        }
    }
}


function autoFly()
{
    $("#ticketQuality").val(flightTicketQuality);
    var flyButton = $(".travel.button.foundation-style");
    flyButton[0].click();
}


function flyResult()
{
    var testDivredWindow = $(".testDivred");
    if (testDivredWindow.length > 1) //有错误时会有2个结果
    {
        alert("飞行出错，停止双击：" + $(".testDivred :last")[0].childNodes[1].nodeValue);
        stop();
    }
    else
    {
        //飞行成功，重新工作
        openUrl( location.origin + "/work.html" );
    }
}


