// ==UserScript==
// @name         Esim gapi fix
// @namespace    EGF
// @version      0.1
// @description  修正因不能下载gapi而导致esim网页坏掉的问题
// @author       Exsper
// @match        https://*.e-sim.org/*
// @grant        unsafewindow
// @run-at       document-start
// ==/UserScript==


function WaitFor$() {
    if (typeof(unsafeWindow.gapi)==="undefined") {
		var gapif = function() {
			this.load = function(s,f) {return;}
		};
        unsafeWindow.gapi = new gapif();
	}
}

WaitFor$();