﻿// ==UserScript==
// @name         e-sim 一键双击 特别版 (GG)
// @namespace    EsimAWT
// @version      0.4 SE
// @description  模拟人工双击，最安全的e-sim双击插件 插件呼出方式：在esim网页地址末尾加上“#”，如：http://secura.e-sim.org/index.html#
// @author       Exsper
// @match        http://*.e-sim.org/*
// @match        https://*.e-sim.org/*
// @grant        none
// ==/UserScript==

//------------------------------------------默认值设置区------------------------------------------
var varAutoWorkEnable = true; //自动工作
var varAutoTrainEnable = true; //自动训练
var varAutoFlight = true; //自动工作时：不在国内自动飞行至工厂所在地
var varFlightTicketQuality = 1; //飞行使用的机票等级，值为1-5
var varhttpProtocol = true; // true = 使用http协议；false = 使用https协议
var varServers = []; //双击服务器列表
//自动双击服务器
var varprimeraEnable = true;
var varsecuraEnable = true;
var varsunaEnable = true;
var varinfernaEnable = true;
var varsuburbiaEnable = true;
var varharmoniaEnable = true;
var varserver1Enable = false;
var varserver2Enable = false;
var varserver1Name = "自定义服务器名称";
var varserver2Name = "自定义服务器名称";
//------------------------------------------------------------------------------------------------

loadSettings();
main();

function setValue(item, value) { //储存数据
    localStorage['AWT-' + item] = value;
}

function getValue(item) { //读取数据
    item = 'AWT-' + item;
    return (item in localStorage) ? localStorage[item] : null;
}

function gE(ele, mode, parent) { //获取元素
    if (typeof ele === 'object') {
        return ele;
    } else if (mode === undefined && parent === undefined) {
        return (isNaN(ele * 1)) ? document.querySelector(ele) : document.getElementById(ele);
    } else if (mode === 'all') {
        return (parent === undefined) ? document.querySelectorAll(ele) : parent.querySelectorAll(ele);
    } else if (typeof mode === 'object' && parent === undefined) {
        return mode.querySelector(ele);
    }
}

function cE(name) { //创建元素
    return document.createElement(name);
}

function openUrl(url, newTab) { //跳转网页
    var a = gE('body').appendChild(cE('a'));
    a.href = url;
    a.target = newTab ? '_blank' : '_self';
    a.click();
}

function loadSettings()
{
    var autoWorkSettings = getValue("AutoWorkEnable");
    if (autoWorkSettings !== null)
    {
        varAutoWorkEnable = (autoWorkSettings == "true") ;
    }

    var autoTrainSettings = getValue("AutoTrainEnable");
    if (autoTrainSettings !== null)
    {
        varAutoTrainEnable = (autoTrainSettings == "true") ;
    }

    var autoTravelSettings = getValue("AutoTravelEnable");
    if (autoTravelSettings !== null)
    {
        varAutoFlight = (autoTravelSettings == "true") ;
    }

    var travelTicketSettings = getValue("FlightTicketQuality");
    if (travelTicketSettings !== null)
    {
        varFlightTicketQuality = parseInt(travelTicketSettings) ;
    }

    var protocolSettings = getValue("Protocol");
    if (protocolSettings !== null)
    {
        varhttpProtocol = (protocolSettings == "true") ;
    }

    var primeraSettings = getValue("primeraEnable");
    if (primeraSettings !== null)
    {
        if (primeraSettings === "true")
        {
            varServers.push("primera");
        }
    }

    var securaSettings = getValue("securaEnable");
    if (securaSettings !== null)
    {
        if (securaSettings === "true")
        {
            varServers.push("secura");
        }
    }

    var sunaSettings = getValue("sunaEnable");
    if (sunaSettings !== null)
    {
        if (sunaSettings === "true")
        {
            varServers.push("suna");
        }
    }

    var infernaSettings = getValue("infernaEnable");
    if (infernaSettings !== null)
    {
        if (infernaSettings === "true")
        {
            varServers.push("inferna");
        }
    }

    var suburbiaSettings = getValue("suburbiaEnable");
    if (suburbiaSettings !== null)
    {
        if (suburbiaSettings === "true")
        {
            varServers.push("suburbia");
        }
    }

    var harmoniaSettings = getValue("harmoniaEnable");
    if (harmoniaSettings !== null)
    {
        if (harmoniaSettings === "true")
        {
            varServers.push("harmonia");
        }
    }

    var server1Settings = getValue("server1Enable");
    if (server1Settings !== null)
    {
        if (server1Settings === "true")
        {
            varServers.push(getValue("server1Name"));
        }
    }

    var server2Settings = getValue("server2Enable");
    if (server2Settings !== null)
    {
        if (server2Settings === "true")
        {
            varServers.push(getValue("server2Name"));
        }
    }
}

function addIcon()
{
    //图标
    var li = $("<li>", {id:"AWTIcon"}).insertBefore($("#userAvatar"));
    var a = $("<a>", {"data-dropdown":"AWTContentDrop", href:"#"}).appendTo(li);
    var img = $("<img>", {align:"absmiddle", class:"smallAvatar", style:"height:36px; width:36px;", src:"http://cdn.e-sim.org/img/premiumPromotion4.png"}).appendTo(a);

    // 版本号和声明
    var AWTContentDrop = $("#contentDrop").clone().attr("id", "AWTContentDrop").empty().insertBefore($("#contentDrop")); // 外框
    $("<b>", {text:"e-sim 一键双击 " + GM_info.script.version}).appendTo(AWTContentDrop).after("<br>"); // 版本号和作者
    $("<div>", {style:"text-align:center;", text:"模拟人工双击，最安全的e-sim双击插件"}).appendTo(AWTContentDrop); // 声明

    // 若干功能选择框和按钮
    var table = $("<table>", {id:"AWTConfig", style:"width:100%;"}).appendTo(AWTContentDrop);

    var tr = $("<tr>", {style:"background-color:DarkSlateGray;"}).appendTo(table);
    var td = $("<td>", {id:"AWTConfigWorkTrain"}).appendTo(tr);


    //自动工作复选框
    var autoWorkCheckbox = $('<input>', {type:'checkbox', style:"vertical-align:5px;", id:'autoWorkCheckbox', text:'自动工作'}).appendTo(td);
    var autoWorkLabel = $("<label>", {class:"checkboxlabel", for:"autoWorkCheckbox", text:'自动工作'}).appendTo(td);
    var autoWorkSettings = getValue("AutoWorkEnable");
    if (autoWorkSettings === null)
    {
        //设置为默认值
        setValue("AutoWorkEnable", varAutoWorkEnable);
        $('#autoWorkCheckbox').attr("checked", varAutoWorkEnable);
    }
    else
    {
        $('#autoWorkCheckbox').attr("checked", autoWorkSettings == "true");
    }
    autoWorkCheckbox.click(function() {
        if ($('#autoWorkCheckbox').is(':checked'))
        {
            setValue("AutoWorkEnable", true);
        }
        else
        {
            setValue("AutoWorkEnable", false);
        }
    });


    //自动训练复选框
    var autoTrainCheckbox = $('<input>', {type:'checkbox', style:"vertical-align:5px;", id:'autoTrainCheckbox', text:'自动训练'}).appendTo(td);
    var autoTrainLabel = $("<label>", {class:"checkboxlabel", for:"autoTrainCheckbox", text:'自动训练'}).appendTo(td);
    var autoTrainSettings = getValue("AutoTrainEnable");
    if (autoTrainSettings === null)
    {
        //设置为默认值
        setValue("AutoTrainEnable", varAutoTrainEnable);
        $('#autoTrainCheckbox').attr("checked", varAutoTrainEnable);
    }
    else
    {
        $('#autoTrainCheckbox').attr("checked", autoTrainSettings == "true");
    }
    autoTrainCheckbox.click(function() {
        if ($('#autoTrainCheckbox').is(':checked'))
        {
            setValue("AutoTrainEnable", true);
        }
        else
        {
            setValue("AutoTrainEnable", false);
        }
    });


    tr = $("<tr>", {style:"background-color:DarkSlateGray;"}).appendTo(table);
    td = $("<td>", {id:"AWTConfigFlight"}).appendTo(tr);


    //自动飞行复选框
    var autoTravelCheckbox = $('<input>', {type:'checkbox', style:"vertical-align:5px;", id:'autoTravelCheckbox', text:'自动飞行到工作地'}).appendTo(td);
    var autoTravelLabel = $("<label>", {class:"checkboxlabel", for:"autoTravelCheckbox", text:'自动飞行到工作地'}).appendTo(td);
    var autoTravelSettings = getValue("AutoTravelEnable");
    if (autoTravelSettings === null)
    {
        //设置为默认值
        setValue("AutoTravelEnable", varAutoFlight);
        $('#autoTravelCheckbox').attr("checked", varAutoFlight);
    }
    else
    {
        $('#autoTravelCheckbox').attr("checked", autoTravelSettings == "true");
    }
    autoTravelCheckbox.click(function() {
        if ($('#autoTravelCheckbox').is(':checked'))
        {
            setValue("AutoTravelEnable", true);
        }
        else
        {
            setValue("AutoTravelEnable", false);
        }
    });


    //机票选择框
    //var selectTicketLabel = $("<p>使用机票：</p>").appendTo(td);
    var selectTicketLabel = $("<p>", {style:"padding:3px; margin:3px", id:"AWTTicketSelectLabel" ,text:"使用机票："}).appendTo(td);
    var selectTicket = $("<select>", {style:"padding:3px; margin:3px", id:"AWTTicketSelect"}).appendTo(selectTicketLabel);
    for (var i=1; i<=5; ++i)
    {
        $("<option>", {value:i, text:"Q"+i}).appendTo(selectTicket);
    }
    var travelTicketSettings = getValue("FlightTicketQuality");
    if (travelTicketSettings === null)
    {
        //设置为默认值
        setValue("FlightTicketQuality", varFlightTicketQuality);
        selectTicket.val(varFlightTicketQuality);
    }
    else
    {
        selectTicket.val(travelTicketSettings);
    }
    selectTicket.change(function() {
        setValue("FlightTicketQuality", selectTicket.val());
    });


    tr = $("<tr>", {style:"background-color:DarkSlateGray;"}).appendTo(table);
    td = $("<td>", {id:"AWTConfigProtocol"}).appendTo(tr);


    //协议复选框
    var protocolCheckbox = $('<input>', {type:'checkbox', style:"vertical-align:5px;", id:'protocolCheckbox', text:'勾选：使用http协议；不勾选：使用https协议'}).appendTo(td);
    var protocolLabel = $("<label>", {class:"checkboxlabel", for:"protocolCheckbox", text:'勾选：使用http协议；不勾选：使用https协议'}).appendTo(td);
    var protocolSettings = getValue("Protocol");
    if (protocolSettings === null)
    {
        //设置为默认值
        setValue("Protocol", varhttpProtocol);
        $('#protocolCheckbox').attr("checked", varhttpProtocol);
    }
    else
    {
        $('#protocolCheckbox').attr("checked", protocolSettings == "true");
    }
    protocolCheckbox.click(function() {
        if ($('#protocolCheckbox').is(':checked'))
        {
            setValue("Protocol", true);
        }
        else
        {
            setValue("Protocol", false);
        }
    });


    tr = $("<tr>", {style:"background-color:DarkSlateGray;"}).appendTo(table);
    td = $("<td>", {id:"AWTConfigPrimeraSecuraSuna"}).appendTo(tr);


    //primera复选框
    var primeraCheckbox = $('<input>', {type:'checkbox', style:"vertical-align:5px;", id:'primeraCheckbox', text:'primera'}).appendTo(td);
    var primeraLabel = $("<label>", {class:"checkboxlabel", for:"primeraCheckbox", text:'primera'}).appendTo(td);
    var primeraSettings = getValue("primeraEnable");
    if (primeraSettings === null)
    {
        //设置为默认值
        setValue("primeraEnable", varprimeraEnable );
        $('#primeraCheckbox').attr("checked", varprimeraEnable );
    }
    else
    {
        $('#primeraCheckbox').attr("checked", primeraSettings == "true");
    }
    primeraCheckbox.click(function() {
        if ($('#primeraCheckbox').is(':checked'))
        {
            setValue("primeraEnable", true);
        }
        else
        {
            setValue("primeraEnable", false);
        }
    });


    //secura复选框
    var securaCheckbox = $('<input>', {type:'checkbox', style:"vertical-align:5px;", id:'securaCheckbox', text:'secura'}).appendTo(td);
    var securaLabel = $("<label>", {class:"checkboxlabel", for:"securaCheckbox", text:'secura'}).appendTo(td);
    var securaSettings = getValue("securaEnable");
    if (securaSettings === null)
    {
        //设置为默认值
        setValue("securaEnable", varsecuraEnable );
        $('#securaCheckbox').attr("checked", varsecuraEnable );
    }
    else
    {
        $('#securaCheckbox').attr("checked", securaSettings == "true");
    }
    securaCheckbox.click(function() {
        if ($('#securaCheckbox').is(':checked'))
        {
            setValue("securaEnable", true);
        }
        else
        {
            setValue("securaEnable", false);
        }
    });


    //suna复选框
    var sunaCheckbox = $('<input>', {type:'checkbox', style:"vertical-align:5px;", id:'sunaCheckbox', text:'suna'}).appendTo(td);
    var sunaLabel = $("<label>", {class:"checkboxlabel", for:"sunaCheckbox", text:'suna'}).appendTo(td);
    var sunaSettings = getValue("sunaEnable");
    if (sunaSettings === null)
    {
        //设置为默认值
        setValue("sunaEnable", varsunaEnable );
        $('#sunaCheckbox').attr("checked", varsunaEnable );
    }
    else
    {
        $('#sunaCheckbox').attr("checked", sunaSettings == "true");
    }
    sunaCheckbox.click(function() {
        if ($('#sunaCheckbox').is(':checked'))
        {
            setValue("sunaEnable", true);
        }
        else
        {
            setValue("sunaEnable", false);
        }
    });


    tr = $("<tr>", {style:"background-color:DarkSlateGray;"}).appendTo(table);
    td = $("<td>", {id:"AWTConfigInfernaSuburbiaHarmonia"}).appendTo(tr);


    //inferna复选框
    var infernaCheckbox = $('<input>', {type:'checkbox', style:"vertical-align:5px;", id:'infernaCheckbox', text:'inferna'}).appendTo(td);
    var infernaLabel = $("<label>", {class:"checkboxlabel", for:"infernaCheckbox", text:'inferna'}).appendTo(td);
    var infernaSettings = getValue("infernaEnable");
    if (infernaSettings === null)
    {
        //设置为默认值
        setValue("infernaEnable", varinfernaEnable );
        $('#infernaCheckbox').attr("checked", varinfernaEnable );
    }
    else
    {
        $('#infernaCheckbox').attr("checked", infernaSettings == "true");
    }
    infernaCheckbox.click(function() {
        if ($('#infernaCheckbox').is(':checked'))
        {
            setValue("infernaEnable", true);
        }
        else
        {
            setValue("infernaEnable", false);
        }
    });


    //suburbia复选框
    var suburbiaCheckbox = $('<input>', {type:'checkbox', style:"vertical-align:5px;", id:'suburbiaCheckbox', text:'suburbia'}).appendTo(td);
    var suburbiaLabel = $("<label>", {class:"checkboxlabel", for:"suburbiaCheckbox", text:'suburbia'}).appendTo(td);
    var suburbiaSettings = getValue("suburbiaEnable");
    if (suburbiaSettings === null)
    {
        //设置为默认值
        setValue("suburbiaEnable", varsuburbiaEnable );
        $('#suburbiaCheckbox').attr("checked", varsuburbiaEnable );
    }
    else
    {
        $('#suburbiaCheckbox').attr("checked", suburbiaSettings == "true");
    }
    suburbiaCheckbox.click(function() {
        if ($('#suburbiaCheckbox').is(':checked'))
        {
            setValue("suburbiaEnable", true);
        }
        else
        {
            setValue("suburbiaEnable", false);
        }
    });


    //harmonia复选框
    var harmoniaCheckbox = $('<input>', {type:'checkbox', style:"vertical-align:5px;", id:'harmoniaCheckbox', text:'harmonia'}).appendTo(td);
    var harmoniaLabel = $("<label>", {class:"checkboxlabel", for:"harmoniaCheckbox", text:'harmonia'}).appendTo(td);
    var harmoniaSettings = getValue("harmoniaEnable");
    if (harmoniaSettings === null)
    {
        //设置为默认值
        setValue("harmoniaEnable", varharmoniaEnable );
        $('#harmoniaCheckbox').attr("checked", varharmoniaEnable );
    }
    else
    {
        $('#harmoniaCheckbox').attr("checked", harmoniaSettings == "true");
    }
    harmoniaCheckbox.click(function() {
        if ($('#harmoniaCheckbox').is(':checked'))
        {
            setValue("harmoniaEnable", true);
        }
        else
        {
            setValue("harmoniaEnable", false);
        }
    });


    tr = $("<tr>", {style:"background-color:DarkSlateGray;"}).appendTo(table);
    td = $("<td>", {id:"AWTConfigExtraServer1"}).appendTo(tr);


    //自定义服1复选框
    var server1Checkbox = $('<input>', {type:'checkbox', style:"vertical-align:5px;", id:'server1Checkbox', text:'server1'}).appendTo(td);
    var server1TextBox = $("<input>", {type:"text", style:"vertical-align:5px;", id:'server1TextBox', text:'自定义服务器名称'}).appendTo(td);

    var server1Settings = getValue("server1Enable");
    if (server1Settings === null)
    {
        //设置为默认值
        setValue("server1Enable", varserver1Enable );
        $('#server1Checkbox').attr("checked", varserver1Enable );
    }
    else
    {
        $('#server1Checkbox').attr("checked", server1Settings == "true");
    }

    var server1Name = getValue("server1Name");
    if (server1Name === null)
    {
        //设置为默认值
        setValue("server1Name", varserver1Name );
        $('#server1TextBox').val(varserver1Name);
    }
    else
    {
        $('#server1TextBox').val(server1Name);
    }

    server1Checkbox.click(function() {
        if ($('#server1Checkbox').is(':checked'))
        {
            setValue("server1Enable", true);
        }
        else
        {
            setValue("server1Enable", false);
        }
    });

    server1TextBox.focus(function() {
        server1TextBox.css("background-color","#FFFFFF");
    });

    server1TextBox.blur(function() {
        if ($('#server1Checkbox').is(':checked'))
        {
            server1TextBox.css("background-color","#79FF79");
        }
        //保存文本框内容
        setValue("server1Name", server1TextBox.val() );
    });


    tr = $("<tr>", {style:"background-color:DarkSlateGray;"}).appendTo(table);
    td = $("<td>", {id:"AWTConfigExtraServer2"}).appendTo(tr);


    //自定义服2复选框
    var server2Checkbox = $('<input>', {type:'checkbox', style:"vertical-align:5px;", id:'server2Checkbox', text:'server2'}).appendTo(td);
    var server2TextBox = $("<input>", {type:"text", style:"vertical-align:5px;", id:'server2TextBox', text:'自定义服务器名称'}).appendTo(td);

    var server2Settings = getValue("server2Enable");
    if (server2Settings === null)
    {
        //设置为默认值
        setValue("server2Enable", varserver2Enable );
        $('#server2Checkbox').attr("checked", varserver2Enable );
    }
    else
    {
        $('#server2Checkbox').attr("checked", server2Settings == "true");
    }

    var server2Name = getValue("server2Name");
    if (server2Name === null)
    {
        //设置为默认值
        setValue("server2Name", varserver2Name );
        $('#server2TextBox').val(varserver2Name);
    }
    else
    {
        $('#server2TextBox').val(server2Name);
    }

    server2Checkbox.click(function() {
        if ($('#server2Checkbox').is(':checked'))
        {
            setValue("server2Enable", true);
        }
        else
        {
            setValue("server2Enable", false);
        }
    });

    server2TextBox.focus(function() {
        server2TextBox.css("background-color","#FFFFFF");
    });

    server2TextBox.blur(function() {
        if ($('#server2Checkbox').is(':checked'))
        {
            server2TextBox.css("background-color","#79FF79");
        }
        //保存文本框内容
        setValue("server2Name", server2TextBox.val() );
    });


    tr = $("<tr>").appendTo(table);
    td = $("<td>", {id:"AWTConfigStart"}).appendTo(tr);


    var startButton = $('<button>', {id:'AWTstart', title:"开始双击", text:"开始双击"}).appendTo(td);
    startButton.click(function() {
        loadSettings();
        nextServer(true);
    });
}

function checkState()
{
    var needWork = false;
    var needTrain = false;

    //确定是否需要双击
    var workButton = $("#taskButtonWork");
    if (workButton.length >0)
    {
        if (varAutoWorkEnable === true)
        {
            setValue('isWorked', false);
            needWork = true;
        }
        else
        {
            //不要自动工作也视为已工作过
            setValue('isWorked', true);
        }
    }
    else
    {
        setValue('isWorked', true);
    }

    var trainButton = $("#taskButtonTrain");
    if (trainButton.length >0)
    {
        if (varAutoTrainEnable === true)
        {
            setValue('isTrained', false);
            needTrain = true;
        }
        else
        {
            //不要自动训练也视为已训练过
            setValue('isTrained', true);
        }
    }
    else
    {
        setValue('isTrained', true);
    }

    var serverName = window.location.host.split('.')[0].toLowerCase();
    if (needWork === true || needTrain === true)
    {
        if (varServers.length <= 0)
        {
            return;
        }

        //为什么呼出菜单要在末尾加#？
        //因为每次进网页都会到这里，当start=false时就会自动启动双击
        //所以在第一次时（按开始前）或者正常游戏的时候要避免自动双击，而要让启动双击后的新页面自动双击
        //就要在第一次加一个特征以便识别
        //但是localstorage不支持跨域
        //所以暂时只能加在网址里
        //不过网页末尾加#有可能会被管理员发现问题
        //所以不能在双击页面加#，采用在其他页面加#呼出菜单的方式，减少加#的次数
        //带来的弊端就是：在双击前不能访问工作、训练、飞行和地区界面，否则还会自动运行起来
        if (document.URL.substring(document.URL.length-1) != "#")
        {
            if ($.inArray(serverName, varServers) != -1)
            {
                start();
            }
        }
    }
    else
    {
        if (document.URL.substring(document.URL.length-1) != "#")
        {
            if ($.inArray(serverName, varServers) != -1)
            {
                nextServer();
            }
            else
            {
                return;
            }
        }
    }
}

function main() {
    if ( $(".time").length !== 2) {
        console.log("未登录，AWT停止运行");
        return;
    }
    /*
    if ($(".time:first").text().match(/-/g).length != 2) {
        console.log("官方脚本还未执行，AWT等待0.5秒");
        setTimeout(main, 500);
        return;
    }
    */
    if (document.URL.substring(document.URL.length-1) == "#")
    {
        //呼出菜单
        addIcon();
        return;
    }

    if(getValue('started') == "true") //已开始自动双击
    {
        if (document.URL.search("html") != -1) {
            var url = document.URL.match("\/([a-zA-Z0-9]+)\.html")[1];
            switch (url) {
                case "work":
                    autoWork();
                    break;
                case "train":
                    autoTrain();
                    break;
                case "region":
                    autoFlight();
                    break;
                case "travel":
                    flyResult();
                    break;
                default:
                    //进了别的网页，应该是人为操作，停止双击
                    stop();
                    alert("奇怪的错误：非双击网页");
                    break;
            }
        }
    }
    else //未开始自动双击，检查状态
    {
        if (document.URL.search("html") != -1) {
            var url2 = document.URL.match("\/([a-zA-Z0-9]+)\.html")[1];
            switch (url2) {
                case "index":
                case "work":
                case "train":
                case "region":
                case "travel":
                    checkState();
                    break;
                default:
                    //进了别的网页，不做任何动作
                    return;
            }
        }
    }
}


function nextServer(isFirst)
{
    stop();
    var serverName;
    var nextServerID;
    var nextUrl;
    serverName = window.location.host.split('.')[0].toLowerCase();
    if (isFirst === true)
    {
        nextServerID = 0;
    }
    else
    {
        nextServerID = $.inArray(serverName, varServers)+1;
        if (nextServerID >= varServers.length)
        {
            finish();
            return;
        }
    }
    if (varhttpProtocol === true)
    {
        nextUrl = "http://" + varServers[nextServerID] + ".e-sim.org/index.html";
    }
    else
    {
        nextUrl = "https://" + varServers[nextServerID] + ".e-sim.org/index.html";
    }
    openUrl(nextUrl);
}

function start()
{
    setValue('isAutoTrained', false);
    setValue('isAutoWorked', false);
    setValue('started', true);
    toAutoWork();
}

function finish()
{
    alarm("双击 已完成");
    //document.title = "〈双击 已完成〉";
}

function stop()
{
    setValue('isAutoTrained', false);
    setValue('isAutoWorked', false);
    setValue('started', false);
}

function toAutoWork()
{
    //判断是否需要工作
    if ((getValue('isWorked') == "true"))
    {
        //不需要工作
        toAutoTrain();
    }
    else //需要工作
    {
        //这里如果防止过快可以加入等待
        openUrl( location.origin + "/work.html" );
    }
}

function toAutoTrain()
{
    //判断是否需要训练
    if (getValue('isTrained') == "true")
    {
        //不需要训练
        nextServer(false);
    }
    else //需要训练
    {
        //这里如果防止过快可以加入等待
        openUrl( location.origin + "/train.html" );
    }
}

//先工作再训练
function autoTrain()
{
    //判断是否需要训练
    if (getValue('isTrained') == "true")
    {
        //不需要训练
        nextServer(false);
    }
    else //需要训练
    {
        if (getValue('isAutoTrained') == "true") //已点击过训练按钮
        {
            var tbt = $("#taskButtonTrain");
            if (tbt.length <= 0)
            {
                //顺利完成自动训练
                nextServer(false);
            }
            else
            {
                //已经自动训练过却未训练成功
                alert("训练出错，停止双击：" + $(".testDivred :last")[0].childNodes[1].nodeValue);
                stop();
            }
        }
        else //未点击过训练按钮
        {
            var trainForm = $("form#command");
            if (trainForm.length <= 0) //没有按钮
            {
                //未训练却没有训练按钮
                alert("奇怪的错误：未训练却没有训练按钮");
                stop();
            }
            else //有按钮
            {
                var trainButton = trainForm.find("input");
                setValue('isAutoTrained', true);
                trainButton[0].click();
                //页面自动刷新
                //有可能会转至未登录界面，但几率过小，暂不做考虑
            }
        }
    }
}

//先工作再训练
function autoWork()
{
    //判断是否需要工作
    if ((getValue('isWorked') == "true"))
    {
        //不需要工作
        toAutoTrain();
    }
    else //需要工作
    {
        if (getValue('isAutoWorked') == "true") //已点击过工作按钮
        {
            var tbw = $("#taskButtonWork");
            if (tbw.length <= 0)
            {
                //顺利完成自动工作
                toAutoTrain();
            }
            else
            {
                //已经自动工作过却未工作成功
                alert("工作出错，停止双击：" + $(".testDivred :last")[0].childNodes[1].nodeValue);
                stop();
            }
        }
        else //未点击过工作按钮
        {
            var workButton = $(".foundation-style.secondary"); //有按钮时会有2个结果，另一个是聊天框
            if (workButton.length <= 1) //没有按钮
            {
                //未工作却没有工作按钮，可能是还没有职业
                alert("奇怪的错误：未工作却没有工作按钮");
                stop();
            }
            else //有按钮
            {
                if (varAutoFlight === true) //自动飞行
                {
                    //判断所在地区
                    var regions = $('a[href^="region.html?id="][href!="region.html?id="]');
                    //regions[0] = 人所在地    regions[1] = 工厂所在地
                    //var userLocationId = parseInt(regions.first().attr('href').replace('region.html?id=', ''));
                    //var companyLocationId = parseInt(regions.last().attr('href').replace('region.html?id=', ''));
                    var userLocationCountry = regions.first().parent().next().attr('class');
                    userLocationCountry = userLocationCountry.split(" ").pop();
                    userLocationCountry = userLocationCountry.substring(userLocationCountry.indexOf('-') + 1);
                    var companyLocationCountry = regions.last().parent().find("div").attr('class');
                    companyLocationCountry = companyLocationCountry.split(" ").pop();
                    companyLocationCountry = companyLocationCountry.substring(companyLocationCountry.indexOf('-') + 1);
                    if (userLocationCountry == companyLocationCountry) //在国内
                    {
                        setValue('isAutoWorked', true);
                        workButton[0].click();
                        //页面自动刷新
                        //有可能会转至未登录界面，但几率过小，暂不做考虑
                    }
                    else //不在国内，去工厂所在地区界面
                    {
                        openUrl( location.origin + "/" + regions.last().attr('href') );
                    }
                }
                else
                {
                    setValue('isAutoWorked', true);
                    workButton[0].click();
                    //页面自动刷新
                    //有可能会转至未登录界面，但几率过小，暂不做考虑
                }
            }
        }
    }
}


function autoFlight()
{
    $("#ticketQuality").val(varFlightTicketQuality);
    var flyButton = $(".travel.button.foundation-style");
    flyButton[0].click();
}


function flyResult()
{
    var testDivredWindow = $(".testDivred");
    if (testDivredWindow.length > 1) //有错误时会有2个结果
    {
        alert("飞行出错，停止双击：" + $(".testDivred :last")[0].childNodes[1].nodeValue);
        stop();
    }
    else
    {
        //飞行成功，重新工作
        openUrl( location.origin + "/work.html" );
    }
}


